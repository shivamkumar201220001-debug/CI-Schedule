# CI Schedule
A basic React + Vite app.