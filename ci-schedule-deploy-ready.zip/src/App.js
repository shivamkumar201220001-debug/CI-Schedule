
import React, { useState } from 'react';
import './App.css';

function App() {
  const [name, setName] = useState('');
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  const handleSubmit = () => {
    if (!name) return;

    const mockData = {
      "Teacher Name": name,
      "Class": "Science 8A",
      "Mon": "9:00 AM - 12:00 PM",
      "Tue": "Week Off",
      "Wed": "10:00 AM - 1:00 PM",
      "Thu": "9:00 AM - 12:00 PM",
      "Fri": "9:00 AM - 11:00 AM",
      "Sat": "10:00 AM - 12:00 PM",
      "Sun": "Week Off"
    };

    setData(mockData);
    setError('');
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-4">
      <div className="bg-white shadow-xl rounded-2xl p-6 w-full max-w-md">
        <h1 className="text-2xl font-bold mb-4 text-center">CI SCHEDULE</h1>
        <input
          type="text"
          placeholder="Enter your name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full border rounded-xl px-4 py-2 mb-4"
        />
        <button onClick={handleSubmit} className="w-full bg-blue-600 text-white py-2 rounded-xl font-semibold">
          View Schedule
        </button>

        {error && <p className="text-red-500 mt-4 text-center">{error}</p>}

        {data && (
          <div className="mt-6">
            <h2 className="text-xl font-semibold mb-2">Name: {data["Teacher Name"]}</h2>
            <h3 className="text-md font-medium mb-2">Class: {data["Class"]}</h3>
            <ul className="space-y-1">
              <li>Mon: {data["Mon"]}</li>
              <li>Tue: {data["Tue"]}</li>
              <li>Wed: {data["Wed"]}</li>
              <li>Thu: {data["Thu"]}</li>
              <li>Fri: {data["Fri"]}</li>
              <li>Sat: {data["Sat"]}</li>
              <li>Sun: {data["Sun"]}</li>
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
